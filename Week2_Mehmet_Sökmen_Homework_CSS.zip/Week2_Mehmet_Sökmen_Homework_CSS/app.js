function who(){
    document.getElementById('wrapper').style.display = 'block'
}
function about(){
    document.getElementById('about').style.display = 'block'
}
function work(){
    document.getElementById('work').style.display = 'block'
}
function hobby(){
    document.getElementById('hobby').style.display = 'block'
}
function video(){
    document.getElementById('video').style.display = 'block'
}